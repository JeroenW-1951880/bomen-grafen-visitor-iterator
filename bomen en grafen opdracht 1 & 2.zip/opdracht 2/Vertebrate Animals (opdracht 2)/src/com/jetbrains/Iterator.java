package com.jetbrains;

public interface Iterator {
    public boolean HasNext(ThreeNode n);

    public ThreeNode GetNext(ThreeNode n);
}
